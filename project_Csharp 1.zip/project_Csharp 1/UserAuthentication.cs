﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Linq;

namespace project_Csharp_1
{
    public class UserNotFoundException : Exception
    {
        public UserNotFoundException(string message) : base(message) { }
    }

    public class UserAccount
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        private string PasswordHash { get; set; }
        public string Email { get; set; }
        public DateTime RegistrationDate { get; set; }

        // Array to simulate database context
        private static UserAccount[] userAccounts = new UserAccount[10];
        private static int userCount = 0;

        // Constructor
        public UserAccount() { }

        // Hash Password
        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }

        // Register User
        public void Register(string username, string email, string password)
        {
            if (userCount >= userAccounts.Length)
            {
                // Resize the array if limit is reached
                Array.Resize(ref userAccounts, userAccounts.Length * 2);
            }

            var user = new UserAccount
            {
                UserId = userCount + 1,
                Username = username,
                PasswordHash = HashPassword(password),
                Email = email,
                RegistrationDate = DateTime.Now
            };

            userAccounts[userCount++] = user;
        }

        // Login User
        public bool Login(string username, string password)
        {
            for (int i = 0; i < userCount; i++)
            {
                if (userAccounts[i].Username == username)
                {
                    return userAccounts[i].PasswordHash == HashPassword(password);
                }
            }

            throw new UserNotFoundException("User not found.");
        }
    }
}