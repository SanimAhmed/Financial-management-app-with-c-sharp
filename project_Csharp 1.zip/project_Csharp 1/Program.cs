﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_Csharp_1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Your code to start the application goes here
            Console.WriteLine("Hello, World!");
            // You can create instances of Expense, Budget, etc., and call their methods for testing
        }
    }

}
